





// const domain = 'http://127.0.0.1/phptest/wxci'
// const domain = 'http://139.199.132.22/wxci'
const domain = 'http://140.143.186.35/wxci'


module.exports = {
    domain,
}