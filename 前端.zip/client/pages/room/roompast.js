const app = getApp()

const log = console.log.bind()

const {
    domain
} = require('../../config')



// pages/room/room.js
Page({

    data: {
        domain
    },





})