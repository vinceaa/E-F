const log = console.log.bind()


Page({


    data: {

    },


    onLoad: function (options) {
        
    },



    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})